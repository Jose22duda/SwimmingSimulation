
//Class to represent a swim team - which has four swimmers
package medleySimulation;

import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import medleySimulation.Swimmer.SwimStroke;

public class SwimTeam extends Thread {
	
	public static StadiumGrid stadium; //shared 
	private Swimmer [] swimmers;
	private int teamNo; //team number
	public static final int sizeOfTeam=4;
    
	// create atomic variables associated with each stroke for a team 
	private final AtomicBoolean TeamBackstroke;
	private final AtomicBoolean TeamBreaststroke;
	private final AtomicBoolean TeamButterfly;
	private final AtomicBoolean TeamFreestyle;
	// create a cyclic barrier
    private final CyclicBarrier barrierOrder1;
	//create atomic variables to check if swimmers have swimmers
	private final AtomicBoolean swimmer1;
	private final AtomicBoolean swimmer2;
	private final AtomicBoolean swimmer3;
	

	SwimTeam( int ID, FinishCounter finish,PeopleLocation [] locArr,CyclicBarrier barrier ) {
		this.teamNo=ID;
		swimmers= new Swimmer[sizeOfTeam];
	    SwimStroke[] strokes = SwimStroke.values();  // Get all enum constants
		stadium.returnStartingBlock(ID);
		//instantiate the atomic booleans for entering stadium
		TeamBackstroke = new AtomicBoolean(false);
		TeamBreaststroke = new AtomicBoolean(false);
		TeamButterfly = new AtomicBoolean(false);
		TeamFreestyle = new AtomicBoolean(false);
        // instantiate the atomic booleans for swimming
		swimmer1=new AtomicBoolean(false);
		swimmer2=new AtomicBoolean(false);
		swimmer3=new AtomicBoolean(false);
		this.barrierOrder1 = barrier;

		for(int i=teamNo*sizeOfTeam,s=0;i<((teamNo+1)*sizeOfTeam); i++,s++) { //initialise swimmers in team
			locArr[i]= new PeopleLocation(i,strokes[s].getColour());
	      	int speed=(int)(Math.random() * (3)+30); //range of speeds 
			swimmers[s] = new Swimmer(i,teamNo,locArr[i],finish,speed,strokes[s]); //hardcoded speed for now
		}
	}
	
	// create a method setting up dependencies betwwen swimmers so that they can check if preceding swimmer has entered stadium for rdering
	public void SetUpDepend(Swimmer swimmer){
		if (swimmer.getSwimStroke().getOrder()==1){
			swimmer.setDependency(TeamBackstroke,TeamBackstroke);
			swimmer.setBarrier(barrierOrder1);
		}
		else if (swimmer.getSwimStroke().getOrder()==2){
			swimmer.setDependency(TeamBackstroke,TeamBreaststroke);
		}
		else if (swimmer.getSwimStroke().getOrder()==3){
			swimmer.setDependency(TeamBreaststroke,TeamButterfly);
		}
		else if (swimmer.getSwimStroke().getOrder()==4){
			swimmer.setDependency(TeamButterfly,TeamFreestyle);	
		}
	}
	// method to check whether a preceding swimstroke order has finished swimming
	public void setSwimDepend(Swimmer swimmer){
		if (swimmer.getSwimStroke().getOrder()==1){
			swimmer.setSwimDependency(swimmer1,swimmer1);
		}
		else if (swimmer.getSwimStroke().getOrder()==2){
			swimmer.setSwimDependency(swimmer1,swimmer2);
		}
		else if (swimmer.getSwimStroke().getOrder()==3){
			swimmer.setSwimDependency(swimmer2,swimmer3);
		}
		else if (swimmer.getSwimStroke().getOrder()==4){
			swimmer.setSwimDependency(swimmer3,swimmer3);
		}

	}
	public void run() {	      
		try {	
			for(int s=0;s<sizeOfTeam; s++) { //start swimmer threads
				SetUpDepend(swimmers[s]);// create dependcy before starting threadU
				setSwimDepend(swimmers[s]);
				swimmers[s].start();
			}	
			
			for(int s=0;s<sizeOfTeam; s++) swimmers[s].join();			//don't really need to do this;
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
	

