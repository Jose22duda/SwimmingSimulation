
//Class representing the grid for the simulation, made up of grid blocks.

package medleySimulation;

// This class represents the club as a grid of GridBlocks
public class StadiumGrid {
    private GridBlock[][] Blocks;
    private final int x; // maximum x value
    private final int y; // maximum y value
    public static int start_y; // where the starting blocks are 

    private GridBlock entrance; // hard coded entrance
    private GridBlock[] startingBlocks; // hard coded starting blocks
    private final static int minX = 5; // minimum x dimension
    private final static int minY = 5; // minimum y dimension

    // Constructor
    StadiumGrid(int x, int y, int nTeams, FinishCounter c) throws InterruptedException {
        if (x < minX) x = minX; // minimum x
        if (y < minY) y = minY; // minimum y
        this.x = x;
        this.y = y;
        start_y = y - 20; // start row hard-coded
        Blocks = new GridBlock[x][y]; // set up the array grid
        startingBlocks = new GridBlock[nTeams];
        this.initGrid();
        entrance = Blocks[0][y - 5];
    }

    // Initialize the grid, creating all the GridBlocks, marking the starting blocks
    private void initGrid() throws InterruptedException {
        int startBIndex = 0;
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                boolean start_block = (i % 5 == 1) && (j == start_y);
                Blocks[i][j] = new GridBlock(i, j, start_block);
                if (start_block) {
                    this.startingBlocks[startBIndex] = Blocks[i][j];
                    startBIndex++;
                }
            }
        }
    }

    public int getMaxX() { return x; }

    public int getMaxY() { return y; }

    public GridBlock whereEntrance() { return entrance; }

    // Check if a position is a valid grid reference
    public boolean inGrid(int i, int j) {
        return (i >= 0 && j >= 0 && i < x && j < y);
    }

    // Check if a position is within stadium area
    public boolean inStadiumArea(int i, int j) {
        return inGrid(i, j);
    }

    // A person enters the stadium
    public synchronized GridBlock enterStadium(PeopleLocation myLocation) throws InterruptedException {    
        while (entrance.occupied()) {
            Thread.sleep(10); // Avoid busy-waiting by adding a small sleep
        }
        entrance.get(myLocation.getID()); // Mark entrance as occupied
        myLocation.setLocation(entrance);
        myLocation.setInStadium(true);
        return entrance;
    }

    // Returns the starting block for a team (the lane)
    public GridBlock returnStartingBlock(int team) {
        return startingBlocks[team];
    }

    // Make a one block move in a direction
    public GridBlock moveTowards(GridBlock currentBlock, int xDir, int yDir, PeopleLocation myLocation) throws InterruptedException {  
        int c_x = currentBlock.getX();
        int c_y = currentBlock.getY();
        
        int add_x = Integer.signum(xDir - c_x); // -1, 0 or 1
        int add_y = Integer.signum(yDir - c_y); // -1, 0 or 1
        
        if (add_x == 0 && add_y == 0) { // Not actually moving
            return currentBlock;
        }
        
        // Restrict i and j to grid
        if (!inStadiumArea(add_x + c_x, add_y + c_y)) {
            System.out.println("Invalid move");
            return currentBlock;
        }

        GridBlock newBlock = (add_x != 0) ? whichBlock(add_x + c_x, c_y) : whichBlock(c_x, add_y + c_y);
        
        while (!newBlock.get(myLocation.getID())) {
            Thread.sleep(10); // Avoid busy-waiting by adding a small sleep
        }
        
        myLocation.setLocation(newBlock);        
        currentBlock.release(); // Must release current block
        return newBlock;
    } 
    
    // Levitate to a specific block
    public synchronized GridBlock jumpTo(GridBlock currentBlock, int x, int y, PeopleLocation myLocation) throws InterruptedException {  
        // Restrict i and j to grid
        if (!inStadiumArea(x, y)) {
            System.out.println("Invalid move");
            return currentBlock;
        }

        GridBlock newBlock = whichBlock(x, y);
        
        while (!newBlock.get(myLocation.getID())) {
            Thread.sleep(10); // Avoid busy-waiting by adding a small sleep
        }
        
        myLocation.setLocation(newBlock);        
        currentBlock.release(); // Must release current block
        return newBlock;
    } 
    
    // Return the grid block at a given position
    public GridBlock whichBlock(int xPos, int yPos) {
        if (inGrid(xPos, yPos)) {
            return Blocks[xPos][yPos];
        }
        System.out.println("Block " + xPos + " " + yPos + " not found");
        return null;
    }
}



	

	

